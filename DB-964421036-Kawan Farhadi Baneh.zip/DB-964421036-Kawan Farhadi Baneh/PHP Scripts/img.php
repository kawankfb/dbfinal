<?php
require "conn.php";
$ID =$_POST["pid"];
$P =$_POST["pnum"];
$ImagePath ='Pictures/'.$ID.'/'.$P.'.jpg';
if(file_exists($ImagePath)){
$Image= fopen($ImagePath,'r');
$content = fread($Image, filesize($ImagePath));
echo base64_encode($content);}
?>