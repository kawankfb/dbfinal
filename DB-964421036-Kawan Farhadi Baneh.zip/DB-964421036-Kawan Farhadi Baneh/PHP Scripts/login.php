<?php
require "conn.php";
$Email =$_POST["email"];
$Pass =$_POST["pass"];
$mysql_qry ="SELECT * FROM user where email like '$Email' and password like '$Pass'; ";
$result = mysqli_query($conn , $mysql_qry);
$arr =mysqli_fetch_array($result);
echo $arr[2];	
?>