<?php
require "conn.php";
$RowNumber=$_POST["row"];
$Condition=$_POST["condition"];
$mysql_qry ="SELECT ID,title,price FROM recent_products ";
if($Condition!="non")
$mysql_qry=$mysql_qry.$Condition;
$mysql_qry=$mysql_qry." LIMIT ".$RowNumber.",1;";
$result =mysqli_query($conn,$mysql_qry);
$arr =mysqli_fetch_array($result);
echo $arr[0].",".$arr[1].",".$arr[2];
$conn->close();
?>