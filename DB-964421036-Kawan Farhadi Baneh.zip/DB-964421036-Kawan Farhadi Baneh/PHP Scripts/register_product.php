<?php
require "conn.php";
$Insurance =$_POST["insurance"];
$Title=$_POST["title"];
$Explanation =$_POST["explanation"];
$Distance =$_POST["distance"];
$Bodywork =$_POST["bodywork"];
$ProductionDate =$_POST["production_date"];
$Color =$_POST["color"];
$Manufacturer =$_POST["manufacturer"];
$CarType =$_POST["car_type"];
$Price =$_POST["price"];
$Model =$_POST["model"];
$UserID =$_POST["user_id"];
$FuelType =$_POST["fuel_type"];
$City =$_POST["city"];
$mysql_qry="SELECT id FROM pid;";
$result =mysqli_query($conn,$mysql_qry);
$arr =mysqli_fetch_array($result);
$ID=$arr[0];
$mysql_qry="UPDATE pid SET id=id+1;";
mysqli_query($conn,$mysql_qry);
$mysql_qry ="INSERT INTO product (ID,insurance,title,explanation,distance,bodywork,production_date,color,manufacturer,car_type,price,model,user_id,fuel_type,city) VALUES('$ID','$Insurance','$Title','$Explanation','$Distance'.'$Bodywork','$ProductionDate','$Color','$Manufacturer','$CarType','$Price','$Model','$UserID','$FuelType','$City');";
mkdir('Pictures/'.$ID);
if($conn->query($mysql_qry)=== TRUE && $conn->query($mysql_qry1)===TRUE)
{
	echo $ID;
}
else echo "Error while submitting Data";
$conn->close();
?>