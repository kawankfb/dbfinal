<?php
require "conn.php";
$Name =$_POST["name"];
$Email =$_POST["email"];
$Phone_Number =$_POST["phone"];
$Address =$_POST["address"];
$PassWord=$_POST["password"];
$mysql_qry ="INSERT INTO user (name,password,Email,phone_number,Address) VALUES('$Name','$PassWord','$Email','$Phone_Number','$Address');";
if($conn->query($mysql_qry)=== TRUE)
{
	echo "Data submitted successfully";
}
else echo "Error while submitting Data";
$conn->close();
?>