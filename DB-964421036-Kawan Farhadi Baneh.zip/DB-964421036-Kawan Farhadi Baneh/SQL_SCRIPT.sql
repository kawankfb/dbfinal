-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 04, 2019 at 02:32 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carsale`
--
CREATE DATABASE IF NOT EXISTS `carsale` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `carsale`;

-- --------------------------------------------------------

--
-- Table structure for table `pid`
--

DROP TABLE IF EXISTS `pid`;
CREATE TABLE IF NOT EXISTS `pid` (
  `name` varchar(31) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pid`
--

INSERT INTO `pid` (`name`, `id`) VALUES
('availableID', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `insurance` int(11) NOT NULL,
  `title` varchar(31) NOT NULL,
  `explanation` text NOT NULL,
  `distance` int(11) NOT NULL,
  `bodywork` int(11) NOT NULL,
  `production_date` int(11) NOT NULL,
  `color` int(11) NOT NULL,
  `manufacturer` int(11) NOT NULL,
  `car_type` int(11) NOT NULL,
  `price` text NOT NULL,
  `model` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fuel_type` int(11) DEFAULT NULL,
  `city` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `date`, `insurance`, `title`, `explanation`, `distance`, `bodywork`, `production_date`, `color`, `manufacturer`, `car_type`, `price`, `model`, `user_id`, `fuel_type`, `city`) VALUES
(1, '2019-07-03 19:32:46', 10, 'gergeg', 'ebhdergter', 0, 0, 1397, 0, 0, 0, '10000000', 0, 6, 0, 0),
(2, '2019-07-03 19:33:03', 10, 'gergeg', 'ebhdergter', 0, 0, 1397, 0, 0, 0, '10000000', 0, 6, 0, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `recent_products`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `recent_products`;
CREATE TABLE IF NOT EXISTS `recent_products` (
`ID` int(11)
,`date` timestamp
,`insurance` int(11)
,`title` varchar(31)
,`explanation` text
,`distance` int(11)
,`bodywork` int(11)
,`production_date` int(11)
,`color` int(11)
,`manufacturer` int(11)
,`car_type` int(11)
,`price` text
,`model` int(11)
,`user_id` int(11)
,`fuel_type` int(11)
,`city` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(31) NOT NULL,
  `password` varchar(31) NOT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(31) NOT NULL,
  `phone_number` varchar(13) NOT NULL,
  `Address` text,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `phone_number` (`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`, `ID`, `Email`, `phone_number`, `Address`) VALUES
('', '', 6, '', '', ''),
('kawan', 'kawan', 7, 'kawan', '0918646', '');

-- --------------------------------------------------------

--
-- Structure for view `recent_products`
--
DROP TABLE IF EXISTS `recent_products`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `recent_products`  AS  select `product`.`ID` AS `ID`,`product`.`date` AS `date`,`product`.`insurance` AS `insurance`,`product`.`title` AS `title`,`product`.`explanation` AS `explanation`,`product`.`distance` AS `distance`,`product`.`bodywork` AS `bodywork`,`product`.`production_date` AS `production_date`,`product`.`color` AS `color`,`product`.`manufacturer` AS `manufacturer`,`product`.`car_type` AS `car_type`,`product`.`price` AS `price`,`product`.`model` AS `model`,`product`.`user_id` AS `user_id`,`product`.`fuel_type` AS `fuel_type`,`product`.`city` AS `city` from `product` order by `product`.`date` desc ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
